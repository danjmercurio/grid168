// CoffeeScript
$('body').addClass('error');
